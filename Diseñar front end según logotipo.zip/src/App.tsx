import { useState, useEffect } from 'react'
import logoImg from '@/imports/Foto_de_Julio_Castellanos__2_.jpg'
import {
  LayoutDashboard, Users, ClipboardList, ShoppingBag,
  BarChart2, Settings, Plus, Search, Filter, Bell,
  ChevronRight, TrendingUp, Clock, CheckCircle2, AlertCircle,
  X, Menu, LogOut, Phone, MessageCircle, Calendar, Scissors,
  Shirt, Tag, FileText, Download, Send, Edit2, Trash2,
  ChevronDown, Star, Package, DollarSign, Eye
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  BarChart, Bar, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts'

// ── Design Tokens ──────────────────────────────────────────────────────────────
const C = {
  wine:    '#3A6B35',
  wineLight: '#4D8A47',
  wineMuted: '#E8F2E7',
  cream:   '#F0F5EF',
  charcoal: '#1A1A1A',
  gray900: '#1F1F1F',
  gray700: '#4A4A4A',
  gray500: '#6B6B6B',
  gray300: '#D1D1D1',
  gray100: '#F4F4F4',
  white:   '#FFFFFF',
  border:  '#E8E8E8',
  success: '#2D7A4F',
  warning: '#B45309',
  info:    '#1D4ED8',
}

// ── Mock Data ──────────────────────────────────────────────────────────────────
const clientes = [
  { id: 1, nombre: 'María González', telefono: '555-1234', whatsapp: '555-1234', fecha: '2024-01-15', visitas: 12, total: 2840 },
  { id: 2, nombre: 'Carmen López', telefono: '555-2345', whatsapp: '555-2345', fecha: '2024-02-03', visitas: 8, total: 1650 },
  { id: 3, nombre: 'Ana Martínez', telefono: '555-3456', whatsapp: '555-3456', fecha: '2024-03-11', visitas: 5, total: 980 },
  { id: 4, nombre: 'Rosa Hernández', telefono: '555-4567', whatsapp: '555-4567', fecha: '2024-04-20', visitas: 3, total: 540 },
  { id: 5, nombre: 'Elena Ramirez', telefono: '555-5678', whatsapp: '555-5678', fecha: '2024-05-08', visitas: 6, total: 1200 },
  { id: 6, nombre: 'Lucía Torres', telefono: '555-6789', whatsapp: '555-6789', fecha: '2024-06-14', visitas: 2, total: 320 },
]

const servicios = [
  { id: 1, nombre: 'Dobladillo pantalón', categoria: 'Compostura', precio: 80, tiempo: '1 día', activo: true },
  { id: 2, nombre: 'Cremallera invisible', categoria: 'Compostura', precio: 150, tiempo: '2 días', activo: true },
  { id: 3, nombre: 'Entalle vestido', categoria: 'Compostura', precio: 200, tiempo: '3 días', activo: true },
  { id: 4, nombre: 'Hechura falda', categoria: 'Hechura', precio: 450, tiempo: '5 días', activo: true },
  { id: 5, nombre: 'Vestido a medida', categoria: 'Diseño', precio: 1200, tiempo: '10 días', activo: true },
  { id: 6, nombre: 'Remiendo invisible', categoria: 'Compostura', precio: 120, tiempo: '1 día', activo: false },
]

const ordenes = [
  { id: 'ORD-001', cliente: 'María González', prenda: 'Pantalón', fecha: '2025-07-15', entrega: '2025-07-17', estado: 'Listo', total: 80 },
  { id: 'ORD-002', cliente: 'Carmen López', prenda: 'Vestido', fecha: '2025-07-14', entrega: '2025-07-19', estado: 'En proceso', total: 350 },
  { id: 'ORD-003', cliente: 'Ana Martínez', prenda: 'Falda', fecha: '2025-07-13', entrega: '2025-07-18', estado: 'Pendiente', total: 200 },
  { id: 'ORD-004', cliente: 'Rosa Hernández', prenda: 'Blusa', fecha: '2025-07-12', entrega: '2025-07-16', estado: 'Listo', total: 120 },
  { id: 'ORD-005', cliente: 'Elena Ramirez', prenda: 'Traje', fecha: '2025-07-11', entrega: '2025-07-21', estado: 'En proceso', total: 680 },
]

const ventasSemanales = [
  { dia: 'Lun', ventas: 380 },
  { dia: 'Mar', ventas: 520 },
  { dia: 'Mié', ventas: 290 },
  { dia: 'Jue', ventas: 710 },
  { dia: 'Vie', ventas: 840 },
  { dia: 'Sáb', ventas: 620 },
  { dia: 'Dom', ventas: 180 },
]

const serviciosPop = [
  { nombre: 'Dobladillo', valor: 38 },
  { nombre: 'Cremallera', valor: 24 },
  { nombre: 'Entalle', valor: 20 },
  { nombre: 'Hechura', valor: 12 },
  { nombre: 'Diseño', valor: 6 },
]

const PIE_COLORS = [C.wine, '#5A8E55', '#7EAD79', '#A8C9A4', '#C8DFC6']

// ── Shared UI ──────────────────────────────────────────────────────────────────
function Badge({ estado }: { estado: string }) {
  const map: Record<string, { bg: string; text: string }> = {
    'Listo':      { bg: '#D1FAE5', text: '#065F46' },
    'En proceso': { bg: '#FEF3C7', text: '#92400E' },
    'Pendiente':  { bg: '#E0E7FF', text: '#3730A3' },
    'Activo':     { bg: '#D1FAE5', text: '#065F46' },
    'Inactivo':   { bg: '#F3F4F6', text: '#6B7280' },
  }
  const s = map[estado] ?? { bg: C.gray100, text: C.gray500 }
  return (
    <span className="px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: s.bg, color: s.text }}>
      {estado}
    </span>
  )
}

function Btn({ children, variant = 'primary', onClick, className = '', size = 'md' }:
  { children: React.ReactNode; variant?: 'primary' | 'secondary' | 'ghost'; onClick?: () => void; className?: string; size?: 'sm' | 'md' }) {
  const base = 'inline-flex items-center gap-2 rounded-xl font-medium transition-all cursor-pointer border-0'
  const sizes = { sm: 'px-3 py-1.5 text-sm', md: 'px-4 py-2.5 text-sm' }
  const variants = {
    primary: `text-white` ,
    secondary: `bg-white border border-[${C.border}] text-[${C.charcoal}] hover:bg-[${C.gray100}]`,
    ghost: `bg-transparent text-[${C.gray500}] hover:bg-[${C.gray100}]`,
  }
  return (
    <button
      onClick={onClick}
      className={`${base} ${sizes[size]} ${className}`}
      style={variant === 'primary' ? { backgroundColor: C.wine, color: C.white } :
             variant === 'secondary' ? { backgroundColor: C.white, border: `1px solid ${C.border}`, color: C.charcoal } :
             { backgroundColor: 'transparent', color: C.gray500 }}
    >
      {children}
    </button>
  )
}

function StatCard({ label, value, icon: Icon, delta, color = C.wine }:
  { label: string; value: string; icon: React.ElementType; delta?: string; color?: string }) {
  return (
    <div className="bg-white rounded-2xl p-5 border" style={{ borderColor: C.border }}>
      <div className="flex items-start justify-between mb-4">
        <div className="p-2.5 rounded-xl" style={{ backgroundColor: C.wineMuted }}>
          <Icon size={18} style={{ color }} />
        </div>
        {delta && (
          <span className="text-xs font-medium flex items-center gap-1" style={{ color: C.success }}>
            <TrendingUp size={12} /> {delta}
          </span>
        )}
      </div>
      <p className="text-2xl font-bold mb-1" style={{ color: C.charcoal }}>{value}</p>
      <p className="text-sm" style={{ color: C.gray500 }}>{label}</p>
    </div>
  )
}

// ── Screens ────────────────────────────────────────────────────────────────────

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')
  const [error, setError] = useState(false)

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: C.cream }}>
      {/* Left panel */}
      <div className="hidden lg:flex w-1/2 flex-col items-center justify-center p-16" style={{ backgroundColor: C.charcoal }}>
        <img src={logoImg} alt="Taller Paola China" className="w-56 h-56 object-contain rounded-full mb-8 opacity-90" style={{ filter: 'brightness(1.1) contrast(0.9) sepia(0.1)' }} />
        <h1 className="text-3xl font-bold text-white text-center mb-3">Taller de Costura<br />Paola China</h1>
        <p className="text-center text-sm" style={{ color: '#9CA3AF' }}>Sistema de gestión interno · Est. 2012</p>
      </div>
      {/* Right panel */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        {/* Logo mobile */}
        <div className="lg:hidden mb-8">
          <img src={logoImg} alt="Taller Paola China" className="w-32 h-32 object-contain rounded-full" />
        </div>
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-bold mb-1" style={{ color: C.charcoal }}>Bienvenida de vuelta</h2>
          <p className="text-sm mb-8" style={{ color: C.gray500 }}>Ingresa tus credenciales para continuar</p>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: C.gray700 }}>Usuario</label>
              <input
                type="text" value={user} onChange={e => { setUser(e.target.value); setError(false) }}
                placeholder="admin"
                className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
                style={{ borderColor: C.border, backgroundColor: C.white, color: C.charcoal }}
                onFocus={e => (e.target.style.borderColor = C.wine)}
                onBlur={e => (e.target.style.borderColor = C.border)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: C.gray700 }}>Contraseña</label>
              <input
                type="password" value={pass} onChange={e => setPass(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
                style={{ borderColor: C.border, backgroundColor: C.white, color: C.charcoal }}
                onFocus={e => (e.target.style.borderColor = C.wine)}
                onBlur={e => (e.target.style.borderColor = C.border)}
              />
            </div>
            {error && (
              <p className="text-sm text-center py-2 px-3 rounded-xl" style={{ backgroundColor: '#FEE2E2', color: '#991B1B' }}>
                Usuario o contraseña incorrectos
              </p>
            )}
            <button
              onClick={() => { if (user === 'paolachina1' && pass === 'cesar81') onLogin(); else setError(true) }}
              className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all mt-2"
              style={{ backgroundColor: C.wine }}
              onMouseEnter={e => ((e.target as HTMLElement).style.backgroundColor = C.wineLight)}
              onMouseLeave={e => ((e.target as HTMLElement).style.backgroundColor = C.wine)}
            >
              Iniciar sesión
            </button>
          </div>
          <p className="text-center text-xs mt-8" style={{ color: C.gray300 }}>
            Taller Paola China · Sistema interno v1.0
          </p>
        </div>
      </div>
    </div>
  )
}

function Dashboard({ setScreen }: { setScreen: (s: string) => void }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Dashboard</h1>
          <p className="text-sm mt-0.5" style={{ color: C.gray500 }}>Viernes, 18 de julio de 2025</p>
        </div>
        <Btn onClick={() => setScreen('nueva-orden')}>
          <Plus size={16} /> Nueva Orden
        </Btn>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Ventas del día" value="$1,430" icon={DollarSign} delta="+12%" />
        <StatCard label="Ventas del mes" value="$18,240" icon={TrendingUp} delta="+8%" />
        <StatCard label="Clientes registrados" value="248" icon={Users} delta="+3" />
        <StatCard label="Órdenes pendientes" value="14" icon={Clock} />
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        {/* Weekly chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-5 border" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm" style={{ color: C.charcoal }}>Ventas de la semana</h3>
            <span className="text-xs px-2.5 py-1 rounded-lg" style={{ backgroundColor: C.wineMuted, color: C.wine }}>Esta semana</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={ventasSemanales}>
              <defs>
                <linearGradient id="wineGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={C.wine} stopOpacity={0.15} />
                  <stop offset="95%" stopColor={C.wine} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={C.gray100} />
              <XAxis dataKey="dia" tick={{ fontSize: 11, fill: C.gray500 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.gray500 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: `1px solid ${C.border}`, fontSize: '12px' }} />
              <Area type="monotone" dataKey="ventas" stroke={C.wine} strokeWidth={2} fill="url(#wineGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Services pie */}
        <div className="bg-white rounded-2xl p-5 border" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-sm mb-4" style={{ color: C.charcoal }}>Servicios populares</h3>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie data={serviciosPop} dataKey="valor" cx="50%" cy="50%" outerRadius={55} innerRadius={30}>
                {serviciosPop.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: '10px', fontSize: '12px' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {serviciosPop.map((s, i) => (
              <div key={s.nombre} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: PIE_COLORS[i] }} />
                  <span className="text-xs" style={{ color: C.gray700 }}>{s.nombre}</span>
                </div>
                <span className="text-xs font-medium" style={{ color: C.charcoal }}>{s.valor}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent orders */}
      <div className="bg-white rounded-2xl border" style={{ borderColor: C.border }}>
        <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-sm" style={{ color: C.charcoal }}>Órdenes recientes</h3>
          <button onClick={() => setScreen('historial')} className="text-xs flex items-center gap-1" style={{ color: C.wine }}>
            Ver todas <ChevronRight size={12} />
          </button>
        </div>
        <div className="divide-y" style={{ borderColor: C.border }}>
          {ordenes.slice(0, 4).map(o => (
            <div key={o.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: C.wineMuted }}>
                  <Shirt size={14} style={{ color: C.wine }} />
                </div>
                <div>
                  <p className="text-sm font-medium" style={{ color: C.charcoal }}>{o.cliente}</p>
                  <p className="text-xs" style={{ color: C.gray500 }}>{o.prenda} · {o.id}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Badge estado={o.estado} />
                <p className="text-sm font-semibold" style={{ color: C.charcoal }}>${o.total}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function ClientesScreen({ setScreen }: { setScreen: (s: string) => void }) {
  const [search, setSearch] = useState('')
  const filtered = clientes.filter(c => c.nombre.toLowerCase().includes(search.toLowerCase()))

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Clientes</h1>
          <p className="text-sm mt-0.5" style={{ color: C.gray500 }}>{clientes.length} clientes registrados</p>
        </div>
        <Btn><Plus size={16} /> Nuevo Cliente</Btn>
      </div>

      <div className="bg-white rounded-2xl border" style={{ borderColor: C.border }}>
        <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: C.border }}>
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.gray300 }} />
            <input
              type="text" placeholder="Buscar cliente..." value={search} onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border text-sm outline-none"
              style={{ borderColor: C.border, color: C.charcoal }}
            />
          </div>
          <Btn variant="secondary" size="sm"><Filter size={14} /> Filtrar</Btn>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {['Cliente', 'Teléfono', 'WhatsApp', 'Registro', 'Visitas', 'Total gastado', ''].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-medium uppercase tracking-wide" style={{ color: C.gray500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} className="hover:bg-gray-50 transition-colors" style={{ borderBottom: `1px solid ${C.gray100}` }}>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ backgroundColor: C.wine }}>
                        {c.nombre.charAt(0)}
                      </div>
                      <span className="text-sm font-medium" style={{ color: C.charcoal }}>{c.nombre}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-1.5 text-sm" style={{ color: C.gray700 }}>
                      <Phone size={13} style={{ color: C.gray300 }} /> {c.telefono}
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-1.5 text-sm" style={{ color: C.gray700 }}>
                      <MessageCircle size={13} style={{ color: '#25D366' }} /> {c.whatsapp}
                    </div>
                  </td>
                  <td className="px-5 py-3.5 text-sm" style={{ color: C.gray500 }}>{c.fecha}</td>
                  <td className="px-5 py-3.5 text-sm font-medium" style={{ color: C.charcoal }}>{c.visitas}</td>
                  <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: C.charcoal }}>${c.total.toLocaleString()}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors" title="Ver perfil">
                        <Eye size={14} style={{ color: C.gray500 }} />
                      </button>
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors" title="Editar">
                        <Edit2 size={14} style={{ color: C.gray500 }} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function NuevaOrdenScreen({ setScreen }: { setScreen: (s: string) => void }) {
  const [selectedServicios, setSelectedServicios] = useState<number[]>([])
  const [clienteInput, setClienteInput] = useState('')
  const [prenda, setPrenda] = useState('')
  const [obs, setObs] = useState('')

  const total = selectedServicios.reduce((acc, id) => {
    const s = servicios.find(sv => sv.id === id)
    return acc + (s?.precio ?? 0)
  }, 0)

  const toggle = (id: number) =>
    setSelectedServicios(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <button onClick={() => setScreen('historial')} className="text-sm flex items-center gap-1 mb-1" style={{ color: C.gray500 }}>
            ← Órdenes
          </button>
          <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Nueva Orden</h1>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary" onClick={() => setScreen('dashboard')}>Cancelar</Btn>
          <Btn onClick={() => setScreen('cotizacion')}>Guardar orden</Btn>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 space-y-5">
          {/* Cliente */}
          <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2" style={{ color: C.charcoal }}>
              <Users size={15} style={{ color: C.wine }} /> Datos del cliente
            </h3>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.gray300 }} />
              <input
                type="text" placeholder="Buscar cliente por nombre o teléfono..."
                value={clienteInput} onChange={e => setClienteInput(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border text-sm outline-none"
                style={{ borderColor: C.border, color: C.charcoal }}
              />
            </div>
            <div className="flex items-center gap-2 mt-3">
              <span className="text-xs" style={{ color: C.gray500 }}>¿Cliente nuevo?</span>
              <button className="text-xs font-medium" style={{ color: C.wine }}>+ Registrar cliente</button>
            </div>
          </div>

          {/* Prenda */}
          <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2" style={{ color: C.charcoal }}>
              <Shirt size={15} style={{ color: C.wine }} /> Prenda
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Tipo de prenda', ph: 'Pantalón, vestido, blusa...', key: 'tipo' },
                { label: 'Marca', ph: 'Opcional', key: 'marca' },
                { label: 'Color', ph: 'Ej. Azul marino', key: 'color' },
                { label: 'Tela / Material', ph: 'Ej. Algodón', key: 'tela' },
              ].map(f => (
                <div key={f.key}>
                  <label className="block text-xs font-medium mb-1.5" style={{ color: C.gray700 }}>{f.label}</label>
                  <input
                    type="text" placeholder={f.ph}
                    className="w-full px-3 py-2 rounded-xl border text-sm outline-none"
                    style={{ borderColor: C.border, color: C.charcoal }}
                  />
                </div>
              ))}
              <div className="col-span-2">
                <label className="block text-xs font-medium mb-1.5" style={{ color: C.gray700 }}>Descripción</label>
                <textarea
                  placeholder="Descripción detallada de la prenda y el servicio requerido..."
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl border text-sm outline-none resize-none"
                  style={{ borderColor: C.border, color: C.charcoal }}
                />
              </div>
            </div>
          </div>

          {/* Servicios */}
          <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2" style={{ color: C.charcoal }}>
              <Scissors size={15} style={{ color: C.wine }} /> Servicios
            </h3>
            <div className="space-y-2">
              {servicios.filter(s => s.activo).map(s => (
                <label
                  key={s.id}
                  className="flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all"
                  style={{
                    backgroundColor: selectedServicios.includes(s.id) ? C.wineMuted : C.gray100,
                    border: `1px solid ${selectedServicios.includes(s.id) ? C.wine : 'transparent'}`,
                  }}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox" className="w-4 h-4 accent-wine rounded"
                      checked={selectedServicios.includes(s.id)}
                      onChange={() => toggle(s.id)}
                      style={{ accentColor: C.wine }}
                    />
                    <div>
                      <p className="text-sm font-medium" style={{ color: C.charcoal }}>{s.nombre}</p>
                      <p className="text-xs" style={{ color: C.gray500 }}>{s.categoria} · {s.tiempo}</p>
                    </div>
                  </div>
                  <span className="text-sm font-semibold" style={{ color: C.wine }}>${s.precio}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Observaciones y fecha */}
          <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2" style={{ color: C.charcoal }}>
              <FileText size={15} style={{ color: C.wine }} /> Detalles finales
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1.5" style={{ color: C.gray700 }}>Fecha de entrega</label>
                <input
                  type="date"
                  className="w-full px-3 py-2 rounded-xl border text-sm outline-none"
                  style={{ borderColor: C.border, color: C.charcoal }}
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1.5" style={{ color: C.gray700 }}>Estado inicial</label>
                <select
                  className="w-full px-3 py-2 rounded-xl border text-sm outline-none"
                  style={{ borderColor: C.border, color: C.charcoal }}
                >
                  <option>Pendiente</option>
                  <option>En proceso</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-medium mb-1.5" style={{ color: C.gray700 }}>Observaciones</label>
                <textarea
                  placeholder="Notas adicionales, instrucciones especiales..."
                  rows={3} value={obs} onChange={e => setObs(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border text-sm outline-none resize-none"
                  style={{ borderColor: C.border, color: C.charcoal }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Summary */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border p-5 sticky top-4" style={{ borderColor: C.border }}>
            <h3 className="font-semibold text-sm mb-4" style={{ color: C.charcoal }}>Resumen de orden</h3>
            {selectedServicios.length === 0 ? (
              <div className="text-center py-8">
                <Scissors size={28} className="mx-auto mb-2" style={{ color: C.gray300 }} />
                <p className="text-sm" style={{ color: C.gray500 }}>Sin servicios seleccionados</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {selectedServicios.map(id => {
                  const s = servicios.find(sv => sv.id === id)!
                  return (
                    <div key={id} className="flex justify-between items-center">
                      <span className="text-sm" style={{ color: C.gray700 }}>{s.nombre}</span>
                      <span className="text-sm font-medium" style={{ color: C.charcoal }}>${s.precio}</span>
                    </div>
                  )
                })}
                <div className="border-t pt-3 mt-3 flex justify-between" style={{ borderColor: C.border }}>
                  <span className="text-sm font-semibold" style={{ color: C.charcoal }}>Total</span>
                  <span className="text-lg font-bold" style={{ color: C.wine }}>${total}</span>
                </div>
              </div>
            )}
            <div className="mt-6 space-y-2">
              <button
                onClick={() => setScreen('cotizacion')}
                className="w-full py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ backgroundColor: C.wine }}
              >
                Guardar y ver cotización
              </button>
              <button
                onClick={() => setScreen('dashboard')}
                className="w-full py-2.5 rounded-xl text-sm font-medium border"
                style={{ borderColor: C.border, color: C.gray700 }}
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function CotizacionScreen({ setScreen }: { setScreen: (s: string) => void }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <button onClick={() => setScreen('nueva-orden')} className="text-sm mb-1 flex items-center gap-1" style={{ color: C.gray500 }}>← Nueva Orden</button>
          <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Cotización</h1>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary"><Download size={15} /> Descargar PDF</Btn>
          <Btn><Send size={15} /> Enviar por WhatsApp</Btn>
        </div>
      </div>

      <div className="max-w-xl mx-auto">
        <div className="bg-white rounded-2xl border overflow-hidden" style={{ borderColor: C.border }}>
          {/* Header */}
          <div className="p-6" style={{ backgroundColor: C.charcoal }}>
            <div className="flex items-center gap-4 mb-4">
              <img src={logoImg} alt="logo" className="w-16 h-16 object-contain rounded-full opacity-90" style={{ filter: 'brightness(1.1)' }} />
              <div>
                <h2 className="text-lg font-bold text-white">Taller de Costura Paola China</h2>
                <p className="text-xs" style={{ color: '#9CA3AF' }}>Est. 2012 · Composturas y diseños a medida</p>
              </div>
            </div>
            <div className="flex justify-between">
              <div>
                <p className="text-xs" style={{ color: '#9CA3AF' }}>Orden #</p>
                <p className="text-sm font-bold text-white">ORD-006</p>
              </div>
              <div>
                <p className="text-xs" style={{ color: '#9CA3AF' }}>Fecha</p>
                <p className="text-sm font-bold text-white">18 Jul 2025</p>
              </div>
              <div>
                <p className="text-xs" style={{ color: '#9CA3AF' }}>Entrega</p>
                <p className="text-sm font-bold text-white">22 Jul 2025</p>
              </div>
            </div>
          </div>

          {/* Cliente */}
          <div className="px-6 py-4 border-b" style={{ borderColor: C.border, backgroundColor: C.cream }}>
            <p className="text-xs font-medium uppercase tracking-wide mb-1" style={{ color: C.gray500 }}>Cliente</p>
            <p className="font-semibold" style={{ color: C.charcoal }}>María González</p>
            <p className="text-sm" style={{ color: C.gray500 }}>WhatsApp: 555-1234</p>
          </div>

          {/* Prenda */}
          <div className="px-6 py-4 border-b" style={{ borderColor: C.border }}>
            <p className="text-xs font-medium uppercase tracking-wide mb-2" style={{ color: C.gray500 }}>Prenda</p>
            <div className="flex items-center gap-2">
              <Shirt size={14} style={{ color: C.wine }} />
              <span className="text-sm" style={{ color: C.charcoal }}>Pantalón azul marino · Algodón</span>
            </div>
          </div>

          {/* Servicios */}
          <div className="px-6 py-4 border-b" style={{ borderColor: C.border }}>
            <p className="text-xs font-medium uppercase tracking-wide mb-3" style={{ color: C.gray500 }}>Servicios</p>
            <div className="space-y-2">
              {[
                { nombre: 'Dobladillo pantalón', precio: 80 },
                { nombre: 'Entalle vestido', precio: 200 },
              ].map(s => (
                <div key={s.nombre} className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Scissors size={12} style={{ color: C.gray300 }} />
                    <span className="text-sm" style={{ color: C.gray700 }}>{s.nombre}</span>
                  </div>
                  <span className="text-sm" style={{ color: C.charcoal }}>${s.precio}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="px-6 py-4 border-b" style={{ borderColor: C.border }}>
            <div className="flex justify-between text-sm mb-1.5">
              <span style={{ color: C.gray500 }}>Subtotal</span>
              <span style={{ color: C.charcoal }}>$280</span>
            </div>
            <div className="flex justify-between text-sm mb-3">
              <span style={{ color: C.gray500 }}>Descuento</span>
              <span style={{ color: C.gray500 }}>—</span>
            </div>
            <div className="flex justify-between items-center pt-3 border-t" style={{ borderColor: C.border }}>
              <span className="font-bold" style={{ color: C.charcoal }}>Total</span>
              <span className="text-2xl font-bold" style={{ color: C.wine }}>$280</span>
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 text-center" style={{ backgroundColor: C.cream }}>
            <p className="text-xs" style={{ color: C.gray500 }}>¡Gracias por confiar en Taller Paola China!</p>
            <p className="text-xs mt-0.5" style={{ color: C.gray300 }}>Est. 2012 · Composturas · Hechuras · Diseño a medida</p>
          </div>
        </div>
      </div>
    </div>
  )
}

function HistorialScreen({ setScreen }: { setScreen: (s: string) => void }) {
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('Todos')
  const estados = ['Todos', 'Pendiente', 'En proceso', 'Listo']
  const filtered = ordenes.filter(o => {
    const matchSearch = o.cliente.toLowerCase().includes(search.toLowerCase()) || o.id.includes(search)
    const matchFilter = filter === 'Todos' || o.estado === filter
    return matchSearch && matchFilter
  })

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Historial de Órdenes</h1>
          <p className="text-sm mt-0.5" style={{ color: C.gray500 }}>{ordenes.length} órdenes en total</p>
        </div>
        <Btn onClick={() => setScreen('nueva-orden')}><Plus size={16} /> Nueva Orden</Btn>
      </div>

      <div className="bg-white rounded-2xl border" style={{ borderColor: C.border }}>
        <div className="flex flex-wrap items-center gap-3 px-5 py-4 border-b" style={{ borderColor: C.border }}>
          <div className="relative flex-1 min-w-48">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.gray300 }} />
            <input
              type="text" placeholder="Buscar por cliente o # de orden..."
              value={search} onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border text-sm outline-none"
              style={{ borderColor: C.border, color: C.charcoal }}
            />
          </div>
          <div className="flex gap-1.5">
            {estados.map(e => (
              <button
                key={e}
                onClick={() => setFilter(e)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                style={{
                  backgroundColor: filter === e ? C.wine : C.gray100,
                  color: filter === e ? C.white : C.gray500,
                }}
              >
                {e}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {['# Orden', 'Cliente', 'Prenda', 'Fecha', 'Entrega', 'Estado', 'Total', ''].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-medium uppercase tracking-wide" style={{ color: C.gray500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(o => (
                <tr key={o.id} className="hover:bg-gray-50 transition-colors" style={{ borderBottom: `1px solid ${C.gray100}` }}>
                  <td className="px-5 py-3.5 text-sm font-mono font-medium" style={{ color: C.wine }}>{o.id}</td>
                  <td className="px-5 py-3.5 text-sm font-medium" style={{ color: C.charcoal }}>{o.cliente}</td>
                  <td className="px-5 py-3.5 text-sm" style={{ color: C.gray700 }}>{o.prenda}</td>
                  <td className="px-5 py-3.5 text-sm" style={{ color: C.gray500 }}>{o.fecha}</td>
                  <td className="px-5 py-3.5 text-sm" style={{ color: C.gray500 }}>{o.entrega}</td>
                  <td className="px-5 py-3.5"><Badge estado={o.estado} /></td>
                  <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: C.charcoal }}>${o.total}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><Eye size={14} style={{ color: C.gray500 }} /></button>
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><Edit2 size={14} style={{ color: C.gray500 }} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function ServiciosScreen() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Catálogo de Servicios</h1>
          <p className="text-sm mt-0.5" style={{ color: C.gray500 }}>{servicios.length} servicios configurados</p>
        </div>
        <Btn><Plus size={16} /> Agregar servicio</Btn>
      </div>

      <div className="bg-white rounded-2xl border" style={{ borderColor: C.border }}>
        <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: C.border }}>
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.gray300 }} />
            <input type="text" placeholder="Buscar servicio..."
              className="w-full pl-9 pr-4 py-2 rounded-xl border text-sm outline-none"
              style={{ borderColor: C.border, color: C.charcoal }} />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${C.border}` }}>
                {['Servicio', 'Categoría', 'Precio', 'Tiempo est.', 'Estado', ''].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-xs font-medium uppercase tracking-wide" style={{ color: C.gray500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {servicios.map(s => (
                <tr key={s.id} className="hover:bg-gray-50 transition-colors" style={{ borderBottom: `1px solid ${C.gray100}` }}>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2">
                      <Scissors size={14} style={{ color: C.wine }} />
                      <span className="text-sm font-medium" style={{ color: C.charcoal }}>{s.nombre}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: C.wineMuted, color: C.wine }}>{s.categoria}</span>
                  </td>
                  <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: C.charcoal }}>${s.precio}</td>
                  <td className="px-5 py-3.5 text-sm" style={{ color: C.gray500 }}>{s.tiempo}</td>
                  <td className="px-5 py-3.5"><Badge estado={s.activo ? 'Activo' : 'Inactivo'} /></td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><Edit2 size={14} style={{ color: C.gray500 }} /></button>
                      <button className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><Trash2 size={14} style={{ color: '#EF4444' }} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function VentasScreen() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Reporte de Ventas</h1>
        <p className="text-sm mt-0.5" style={{ color: C.gray500 }}>Julio 2025</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Ingresos del mes" value="$18,240" icon={DollarSign} delta="+8%" />
        <StatCard label="Ticket promedio" value="$284" icon={TrendingUp} delta="+5%" />
        <StatCard label="Órdenes completadas" value="64" icon={CheckCircle2} delta="+12" />
        <StatCard label="Clientes frecuentes" value="18" icon={Star} />
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-sm mb-4" style={{ color: C.charcoal }}>Ventas por día (semana actual)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={ventasSemanales}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.gray100} />
              <XAxis dataKey="dia" tick={{ fontSize: 11, fill: C.gray500 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: C.gray500 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: `1px solid ${C.border}`, fontSize: '12px' }} />
              <Bar dataKey="ventas" fill={C.wine} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-sm mb-4" style={{ color: C.charcoal }}>Servicios más vendidos</h3>
          <div className="space-y-3">
            {serviciosPop.map((s, i) => (
              <div key={s.nombre}>
                <div className="flex justify-between text-sm mb-1">
                  <span style={{ color: C.gray700 }}>{s.nombre}</span>
                  <span className="font-medium" style={{ color: C.charcoal }}>{s.valor}%</span>
                </div>
                <div className="h-2 rounded-full" style={{ backgroundColor: C.gray100 }}>
                  <div className="h-2 rounded-full" style={{ width: `${s.valor}%`, backgroundColor: PIE_COLORS[i] }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function ConfigScreen() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold" style={{ color: C.charcoal }}>Configuración</h1>
        <p className="text-sm mt-0.5" style={{ color: C.gray500 }}>Datos del negocio y preferencias</p>
      </div>

      <div className="max-w-2xl space-y-5">
        <div className="bg-white rounded-2xl border p-6" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-sm mb-5" style={{ color: C.charcoal }}>Datos del negocio</h3>
          <div className="flex items-center gap-5 mb-6">
            <img src={logoImg} alt="logo" className="w-20 h-20 object-contain rounded-full border-2" style={{ borderColor: C.border }} />
            <div>
              <p className="text-sm font-medium" style={{ color: C.charcoal }}>Logo del taller</p>
              <p className="text-xs mb-2" style={{ color: C.gray500 }}>Formato PNG o JPG recomendado</p>
              <Btn variant="secondary" size="sm">Cambiar logo</Btn>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Nombre del taller', value: 'Taller de Costura Paola China' },
              { label: 'Dirección', value: 'Calle Principal #123, Col. Centro' },
              { label: 'WhatsApp', value: '555-0000' },
              { label: 'Facebook', value: 'fb.com/tallerpaolachina' },
              { label: 'Instagram', value: '@tallerpaolachina' },
              { label: 'Horario', value: 'Lun-Sáb 9:00-19:00' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-xs font-medium mb-1.5" style={{ color: C.gray700 }}>{f.label}</label>
                <input
                  type="text" defaultValue={f.value}
                  className="w-full px-3 py-2.5 rounded-xl border text-sm outline-none"
                  style={{ borderColor: C.border, color: C.charcoal }}
                />
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-end">
            <Btn>Guardar cambios</Btn>
          </div>
        </div>

        <div className="bg-white rounded-2xl border p-6" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-sm mb-4" style={{ color: C.charcoal }}>Políticas del taller</h3>
          <textarea
            rows={5} defaultValue="• Las prendas deben ser recogidas en un plazo máximo de 30 días.&#10;• No nos hacemos responsables por artículos olvidados.&#10;• El pago se realiza al momento de entregar la prenda.&#10;• Revisión gratuita en los 7 días siguientes a la entrega."
            className="w-full px-3 py-2.5 rounded-xl border text-sm outline-none resize-none"
            style={{ borderColor: C.border, color: C.charcoal }}
          />
          <div className="mt-3 flex justify-end">
            <Btn>Guardar políticas</Btn>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Main Layout ────────────────────────────────────────────────────────────────
const NAV = [
  { key: 'dashboard',    label: 'Dashboard',    icon: LayoutDashboard },
  { key: 'clientes',     label: 'Clientes',     icon: Users },
  { key: 'historial',   label: 'Órdenes',      icon: ClipboardList },
  { key: 'servicios',   label: 'Servicios',    icon: Scissors },
  { key: 'ventas',      label: 'Ventas',       icon: BarChart2 },
  { key: 'config',      label: 'Configuración', icon: Settings },
]

function AppLayout({ screen, setScreen }: { screen: string; setScreen: (s: string) => void }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const activeNav = NAV.find(n => n.key === screen) ?? NAV[0]

  const renderScreen = () => {
    if (screen === 'dashboard')    return <Dashboard setScreen={setScreen} />
    if (screen === 'clientes')     return <ClientesScreen setScreen={setScreen} />
    if (screen === 'nueva-orden')  return <NuevaOrdenScreen setScreen={setScreen} />
    if (screen === 'cotizacion')   return <CotizacionScreen setScreen={setScreen} />
    if (screen === 'historial')    return <HistorialScreen setScreen={setScreen} />
    if (screen === 'servicios')    return <ServiciosScreen />
    if (screen === 'ventas')       return <VentasScreen />
    if (screen === 'config')       return <ConfigScreen />
    return <Dashboard setScreen={setScreen} />
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ backgroundColor: C.gray100, fontFamily: 'Inter, system-ui, sans-serif' }}>
      {/* Overlay mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-30 flex flex-col transition-transform duration-200 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
        style={{ width: 240, backgroundColor: C.charcoal, flexShrink: 0 }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b" style={{ borderColor: '#2D2D2D' }}>
          <img src={logoImg} alt="Taller Paola China" className="w-9 h-9 object-contain rounded-full" style={{ filter: 'brightness(1.1)' }} />
          <div>
            <p className="text-white text-sm font-semibold leading-tight">Paola China</p>
            <p className="text-xs" style={{ color: '#6B7280' }}>Taller de costura</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV.map(n => {
            const active = screen === n.key || (screen === 'nueva-orden' && n.key === 'historial')
            return (
              <button
                key={n.key}
                onClick={() => { setScreen(n.key); setSidebarOpen(false) }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-left"
                style={{
                  backgroundColor: active ? C.wine : 'transparent',
                  color: active ? C.white : '#9CA3AF',
                }}
              >
                <n.icon size={16} />
                {n.label}
              </button>
            )
          })}
        </nav>

        {/* User */}
        <div className="px-3 py-4 border-t" style={{ borderColor: '#2D2D2D' }}>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-white/5 transition-colors">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ backgroundColor: C.wine }}>P</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">Paola China</p>
              <p className="text-xs truncate" style={{ color: '#6B7280' }}>Administradora</p>
            </div>
            <LogOut size={14} style={{ color: '#6B7280' }} />
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="flex items-center justify-between px-5 py-3.5 bg-white border-b" style={{ borderColor: C.border }}>
          <div className="flex items-center gap-3">
            <button className="lg:hidden p-1.5 rounded-lg" onClick={() => setSidebarOpen(true)}>
              <Menu size={18} style={{ color: C.gray500 }} />
            </button>
            <div className="hidden lg:flex items-center gap-1.5 text-sm" style={{ color: C.gray500 }}>
              <span>Sistema</span>
              <ChevronRight size={13} />
              <span className="font-medium" style={{ color: C.charcoal }}>{activeNav.label}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-xl hover:bg-gray-100 transition-colors">
              <Bell size={17} style={{ color: C.gray500 }} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full" style={{ backgroundColor: C.wine }} />
            </button>
            <Btn onClick={() => setScreen('nueva-orden')} size="sm">
              <Plus size={14} /> Nueva Orden
            </Btn>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-5 lg:p-7">
          {renderScreen()}
        </main>
      </div>
    </div>
  )
}

// ── Root ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [screen, setScreen] = useState('dashboard')

  if (!loggedIn) return <LoginScreen onLogin={() => setLoggedIn(true)} />
  return <AppLayout screen={screen} setScreen={setScreen} />
}
