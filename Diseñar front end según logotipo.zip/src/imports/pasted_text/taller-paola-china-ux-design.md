Actúa como un UX/UI Designer Senior especializado en sistemas ERP y CRM para pequeñas empresas.

Diseña un prototipo profesional en Figma para un sistema web responsive llamado "Taller Paola China", un taller de costura especializado en composturas (80% de sus ingresos), hechuras y diseños a medida.

El objetivo principal del sistema es digitalizar completamente el proceso de atención al cliente y eliminar el uso de libretas o registros manuales.

La interfaz debe ser moderna, minimalista, elegante y muy fácil de utilizar para personas con pocos conocimientos tecnológicos.

Inspirarse en sistemas como Notion, Stripe Dashboard, Linear y Shopify Admin.

Utilizar una paleta con colores blanco, negro, gris claro y un color principal vino/burdeos (#7A1E2C).

Usar tipografía Inter.

Componentes con esquinas redondeadas.

Mucho espacio en blanco.

Iconografía de Lucide Icons.

Diseño responsive.

==========================================
OBJETIVO DEL MVP
==========================================

El sistema debe permitir:

• Registrar clientes.
• Registrar prendas.
• Registrar composturas y servicios.
• Calcular automáticamente el precio.
• Generar un resumen de la orden.
• Consultar el historial de clientes.
• Consultar ventas del día.

NO incluir facturación SAT.

NO incluir inventario.

NO incluir sistema de empleados.

NO incluir pagos en línea.

==========================================
PANTALLAS
==========================================

1. Login

- Logo del taller
- Usuario
- Contraseña
- Botón Iniciar sesión

------------------------------------------

2. Dashboard

Mostrar tarjetas con:

Ventas del día

Ventas del mes

Clientes registrados

Órdenes pendientes

Servicios realizados

Gráfica sencilla de ventas semanales

Lista de órdenes recientes

Botón Nueva Orden

------------------------------------------

3. Clientes

Tabla con:

Nombre

Teléfono

WhatsApp

Fecha de registro

Número de visitas

Total gastado

Buscador

Filtro

Botón Nuevo Cliente

Panel lateral para editar información

------------------------------------------

4. Perfil del Cliente

Mostrar:

Información personal

Historial de órdenes

Total gastado

Servicios más solicitados

Botón Crear nueva orden

------------------------------------------

5. Catálogo de Servicios

Tabla editable

Servicio

Categoría

Precio

Tiempo estimado

Estado

Buscador

Agregar servicio

Editar servicio

Eliminar servicio

------------------------------------------

6. Nueva Orden

Formulario dividido en tarjetas.

Datos del cliente.

Prenda.

Tipo de prenda

Marca

Color

Tela

Descripción

Fotografía

Servicios seleccionados.

Checkbox de servicios.

Cada servicio suma automáticamente.

Observaciones.

Fecha de entrega.

Estado.

Botón Guardar.

Botón Cancelar.

------------------------------------------

7. Cotización

Vista tipo ticket.

Cliente

Prenda

Lista de servicios

Precio individual

Subtotal

Descuento

Total

Fecha de entrega

Botón Descargar PDF

Botón Compartir por WhatsApp

------------------------------------------

8. Historial de Órdenes

Tabla

Cliente

Prenda

Fecha

Estado

Total

Buscador

Filtros

------------------------------------------

9. Dashboard de Ventas

Gráficas

Ventas por día

Ventas por semana

Servicios más vendidos

Clientes frecuentes

Ingresos mensuales

Ticket promedio

------------------------------------------

10. Configuración

Datos del negocio

Nombre

Logo

Dirección

WhatsApp

Facebook

Instagram

Horario

Políticas

==========================================
COMPONENTES
==========================================

Sidebar fija.

Topbar.

Cards.

Tablas.

Modal.

Drawer.

Toast.

Calendario.

Select.

Checkbox.

Search.

Filtros.

Botones primario y secundario.

==========================================
FLUJO PRINCIPAL
==========================================

Cliente llega.

↓

Buscar cliente.

↓

Si no existe crear cliente.

↓

Registrar prenda.

↓

Seleccionar servicios.

↓

El sistema calcula automáticamente el costo.

↓

Guardar orden.

↓

Mostrar resumen.

↓

Descargar PDF.

↓

Enviar por WhatsApp.

==========================================
DISEÑO
==========================================

Muy limpio.

Profesional.

Minimalista.

Espacios amplios.

Tablas fáciles de leer.

Colores suaves.

Botones grandes.

Experiencia intuitiva.

Diseño similar a los productos SaaS modernos.

==========================================
ENTREGABLE
==========================================

Generar todas las pantallas conectadas mediante prototipo navegable.

Crear componentes reutilizables.

Usar Auto Layout.

Usar Variables de Color.

Usar Design Tokens.

Crear un pequeño Design System.

Preparar el archivo para futura implementación en Next.js + TailwindCSS + shadcn/ui.